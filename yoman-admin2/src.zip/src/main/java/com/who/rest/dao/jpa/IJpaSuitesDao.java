package com.who.rest.dao.jpa;

import com.who.rest.dao.IDao;
import com.who.rest.dao.Dao;
import com.who.rest.db.model.Suites;

public interface IJpaSuitesDao extends IDao<Suites, Integer>
{

}