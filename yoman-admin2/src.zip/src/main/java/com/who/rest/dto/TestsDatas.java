package com.who.rest.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class TestsDatas {

	List<TestsData> tests = new ArrayList<TestsData>();

	public List<TestsData> getTests() {
		return tests;
	}

	public void setTests(List<TestsData> suites) {
		tests = suites;
	}

	
}
