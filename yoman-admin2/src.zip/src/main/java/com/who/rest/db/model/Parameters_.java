package com.who.rest.db.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2014-06-15T13:44:07.557+0300")
@StaticMetamodel(Parameters.class)
public class Parameters_ {
	public static volatile SingularAttribute<Parameters, Integer> parameterId;
	public static volatile SingularAttribute<Parameters, Tests> tests;
	public static volatile SingularAttribute<Parameters, String> parameterName;
	public static volatile SingularAttribute<Parameters, String> parameterValue;
}
