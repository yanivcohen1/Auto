package com.who.rest.dao;

import java.io.Serializable;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.who.security.entity.Entity;

public class Dao<T, I> implements IDao<T , I>
{

	private EntityManager entityManager;

	protected Class<T> entityClass;


	public Dao(Class<T> entityClass)
	{
		this.entityClass = entityClass;
	}


	public EntityManager getEntityManager()
	{
		return this.entityManager;
	}


	@PersistenceContext
	public void setEntityManager(final EntityManager entityManager)
	{
		this.entityManager = entityManager;
	}


	@Override
	@Transactional(readOnly = true)
	public List<T> findAll()
	{
		final CriteriaBuilder builder = this.getEntityManager().getCriteriaBuilder();
		final CriteriaQuery<T> criteriaQuery = builder.createQuery(this.entityClass);

		criteriaQuery.from(this.entityClass);

		TypedQuery<T> typedQuery = this.getEntityManager().createQuery(criteriaQuery);
		return typedQuery.getResultList();
	}


	@Override
	@Transactional(readOnly = true)
	public T find(Integer id)
	{
		return this.getEntityManager().find(this.entityClass, id);
	}


	@Override
	@Transactional
	public T save(T entity)
	{
		 this.getEntityManager().persist(entity);
		 return entity;
	}


	@Override
	@Transactional
	public void delete(Integer id)
	{
		if (id == null) {
			return;
		}

		T entity = this.find(id);
		if (entity == null) {
			return;
		}

		this.getEntityManager().remove(entity);
	}

	@Override
	@Transactional(readOnly = true)
	public List<T> runQuery(Query query)
	{
		 return query.getResultList();
	}
	//Common.getEntityManager().createQuery(HQL)
}