package com.who.rest.dao.jpa;

import com.who.rest.dao.IDao;
import com.who.rest.dao.Dao;
import com.who.rest.db.model.Classe;
import com.who.rest.db.model.Suites;

public interface IJpaClasseDao extends IDao<Classe, Integer>
{

}