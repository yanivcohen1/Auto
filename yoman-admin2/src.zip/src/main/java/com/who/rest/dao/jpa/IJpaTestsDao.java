package com.who.rest.dao.jpa;

import com.who.rest.dao.IDao;
import com.who.rest.dao.Dao;
import com.who.rest.db.model.Suites;
import com.who.rest.db.model.Tests;

public interface IJpaTestsDao extends IDao<Tests, Integer>
{

}