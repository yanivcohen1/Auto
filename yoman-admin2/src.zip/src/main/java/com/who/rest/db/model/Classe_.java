package com.who.rest.db.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2014-06-15T13:44:07.554+0300")
@StaticMetamodel(Classe.class)
public class Classe_ {
	public static volatile SingularAttribute<Classe, Integer> classId;
	public static volatile SingularAttribute<Classe, Tests> tests;
	public static volatile SingularAttribute<Classe, String> className;
}
