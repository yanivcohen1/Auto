package com.who.rest.dto;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ManualTestIn {

	private String inUrl;
	private String expectedUrl;
	
	public String getInUrl() {
		return inUrl;
	}
	public void setInUrl(String inUrl) {
		this.inUrl = inUrl;
	}
	public String getExpectedUrl() {
		return expectedUrl;
	}
	public void setExpectedUrl(String expectedUrl) {
		this.expectedUrl = expectedUrl;
	}
	
}
