package com.who.security;

public class JsonViews
{

	public static class User
	{
	}

	public static class Admin extends User
	{
	}

}
