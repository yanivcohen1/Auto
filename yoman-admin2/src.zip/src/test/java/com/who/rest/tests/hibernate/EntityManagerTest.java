package com.who.rest.tests.hibernate;

import com.who.rest.db.model.Classe;
import com.who.rest.db.model.Suites;

public class EntityManagerTest extends BaseHiberTest {

	public void testLeerEntityManager() throws Exception {

		Suites suites = getEntityManager().find(Suites.class, 1);
		System.out.println(suites.getSuiteName());
	}

}
