namespace simpleDLLNS
{
    class simpleDLL
    {
    public:
        // Returns a + b
        char giveVoidPtrGetChar(void* param);
		int giveIntGetInt(int a);
		void simpleCall();
		int giveVoidPtrGetInt(void* param);
    };
}