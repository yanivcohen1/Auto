// MathFuncsDll.cpp
// compile with: /EHsc /LD

#include "simpleDLL.h"

#include <stdexcept>

using namespace std;

namespace simpleDLLNS
{
    char simpleDLL::giveVoidPtrGetChar(void* param)
    {
        if(param != 0)
		{
		char* paramChrPtr = (char*)param;
		return *paramChrPtr;
		}
		else
		{
			return 'x';
		}

    }

	int simpleDLL::giveIntGetInt(int a)
	{
		return 2*a;
	}

	void simpleDLL::simpleCall(void)
	{
		int x = 3;
		return;
	}

	int simpleDLL::giveVoidPtrGetInt(void* param)
	{
		if(param!=0)
		{
			int* x = (int*)param;
			return *x;

		}
		else
		{
			return -1;
		}
	}

  
}