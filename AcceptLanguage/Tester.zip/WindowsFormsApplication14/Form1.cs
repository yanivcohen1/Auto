﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Cache;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication14
{
    public partial class Form1 : Form
    {
        int Tickcunt1;
        static string[] sites = {"http://www.microsoft.com", "http://www.google.com","http://msdn.microsoft.com/en-us/library/ms973903.aspx",
                                  "http://msdn.microsoft.com/en-us/concurrency/default.aspx","http://redown.com/softwares/205777-developer-express-dxperience-universal-2010.1.5.html",
                                  "https://www.devexpress.com","http://translate.google.co.il/?hl=iw&tab=wT#","http://www.youtube.com/?hl=iw&tab=Y1&gl=IL"};
        static string TB, BL, L, res;
        string a = "a";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //string[] sites = { "http://www.williamhillcasino.com/", "http://www.eurogrand.com" };
            BransList.Items.Insert(0, "http://www.williamhillcasino.com");
            BransList.Items.Insert(0, "http://www.eurogrand.com");
            Languages.Items.Insert(0, "sv-sv");
            Languages.Items.Insert(0, "ru-ru");
            Languages.Items.Insert(0, "fr-fr");
            Languages.Items.Insert(0, "de-de");
            Languages.Items.Insert(0, "ro-ro");
            textBox1.Text = "8";
        }

        public void button1_Click(object sender, EventArgs e)
        {
            TB = textBox1.Text;
            //BL = BransList.SelectedItem.ToString();
            //L = Languages.SelectedItem.ToString();
            res = "";
            List<IAsyncResult> arl = new List<IAsyncResult>();
            List<HttpWebRequest> requests = new List<HttpWebRequest>();
            for (int i = 0; i < Languages.Items.Count; i++)//Convert.ToInt32(TB)
            {
                HttpWebRequest request;
                IAsyncResult ar;
                request = (HttpWebRequest)WebRequest.CreateDefault(new Uri(BransList.SelectedItem.ToString()));//sites[(int)i]
                request.UserAgent = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";
                WebHeaderCollection WebHeaderCollection1 = request.Headers;
                WebHeaderCollection1.Add("Accept-Language:" + Languages.Items[i]);
                HttpRequestCachePolicy policy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
                HttpWebRequest.DefaultCachePolicy = policy;
                request.Timeout = 10000;
                ar = request.BeginGetResponse(new AsyncCallback(PoolFunc), request);
                arl.Add(ar);
                requests.Add(request);
            }
            Tickcunt1 = Environment.TickCount;
            Parallel.ForEach(arl, Item =>
            {
                Item.AsyncWaitHandle.WaitOne(10000);
            });
            Result.Text += res;
            foreach (var item in requests)
            {
                item.Abort();
            }
        }

        void PoolFunc(IAsyncResult ar)
        {
            int ind = Convert.ToInt32(TB);
            //int Tickcunt = Environment.TickCount;
            HttpWebRequest request;
            HttpWebResponse response;
            //HttpWebRequest1.MaximumAutomaticRedirections = 10;
            //WebHeaderCollection WebHeaderCollection = HttpWebRequest1.Headers;
            // WebHeaderCollection.Add("Accept-Language:" + L);
            string msg = null;
            string response_url;
            string IsFromCache = "";
            request = (HttpWebRequest)ar.AsyncState;
            try
            {
                response = (HttpWebResponse)request.EndGetResponse(ar);
                response_url = response.ResponseUri.AbsoluteUri;
                IsFromCache = " IsFromCache? " + response.IsFromCache.ToString();
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                response_url = "";
            }
            double time = (Environment.TickCount - Tickcunt1) / 1000.0;
            res += response_url + " time: " + time + "  " + msg + "ThreadID: " + Thread.CurrentThread.ManagedThreadId + IsFromCache + "\r\n";
            //Thread.Sleep(0);// .CurrentThread.sleap;
            request.Abort();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            TB = textBox1.Text;
            res = "";
            List<Thread> ThreadList = new List<Thread>();
            for (int i = 0; i < Convert.ToInt32(TB); i++)
            {
                HttpWebRequest request = (HttpWebRequest)WebRequest.CreateDefault(new Uri(sites[(int)i]));
                request.Timeout = 10000;
                Thread NewThread = new Thread(ThreadFun);
                ThreadList.Add(NewThread);
                NewThread.Start(request);
            }
            foreach (var item in ThreadList)
            {
                item.Join();
            }
            Result.Text += res;
        }

        public void ThreadFun(object request)
        {
            int Tickcunt = Environment.TickCount;
            HttpWebRequest _request = (HttpWebRequest)request;
            string msg = null;
            string response_url;
            try
            {
                using (HttpWebResponse response = (HttpWebResponse)_request.GetResponse())
                {
                    response_url = response.ResponseUri.AbsoluteUri;
                }
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                response_url = "";
            }
            double time = (Environment.TickCount - Tickcunt) / 1000.0;
            res += response_url + " time: " + time + "  " + msg + "ThreadID: " + Thread.CurrentThread.ManagedThreadId + "\r\n";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TB = textBox1.Text;
            res = "";
            List<Thread> ThreadList = new List<Thread>();
            for (int i = 0; i < Convert.ToInt32(TB); i++)
            {
                IAsyncResult ar;
                HttpWebRequest request = (HttpWebRequest)WebRequest.CreateDefault(new Uri(sites[(int)i]));
                request.Timeout = 10000;
                Thread NewThread = new Thread(ThreadAsyncFun);
                ThreadList.Add(NewThread);
                NewThread.Start(request);
            }
            foreach (var item in ThreadList)
            {
                item.Join();
            }
            Result.Text += res;
        }

        private void ThreadAsyncFun(object request)
        {
            //List<IAsyncResult> arl = new List<IAsyncResult>();
            IAsyncResult ar;
            ar = ((HttpWebRequest)request).BeginGetResponse(new AsyncCallback(AsyncPoolFunc), request);
            ar.AsyncWaitHandle.WaitOne();
        }

        private void AsyncPoolFunc(IAsyncResult ar)
        {
            int ind = Convert.ToInt32(TB);
            int Tickcunt = Environment.TickCount;
            HttpWebRequest request;
            HttpWebResponse response;
            //HttpWebRequest1.MaximumAutomaticRedirections = 10;
            //WebHeaderCollection WebHeaderCollection = HttpWebRequest1.Headers;
            // WebHeaderCollection.Add("Accept-Language:" + L);
            string msg = null;
            string response_url;
            try
            {
                request = (HttpWebRequest)ar.AsyncState;
                response = (HttpWebResponse)request.EndGetResponse(ar);
                response_url = response.ResponseUri.AbsoluteUri;
            }
            catch (Exception ex)
            {
                msg = ex.Message;
                response_url = "";
            }
            double time = (Environment.TickCount - Tickcunt) / 1000.0;
            res += response_url + " time: " + time + "  " + msg + "ThreadID: " + Thread.CurrentThread.ManagedThreadId + "\r\n";
        }

        private void button_Sync_Click(object sender, EventArgs e)
        {
            TB = textBox1.Text;
            res = "";
            Tickcunt1 = Environment.TickCount;
            for (int i = 0; i < Languages.Items.Count; i++)//Convert.ToInt32(TB)
            {
                double Tickcunt = Environment.TickCount;
                HttpWebRequest request = (HttpWebRequest)WebRequest.CreateDefault(new Uri(BransList.SelectedItem.ToString()));//sites[(int)i]
                request.UserAgent = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";
                WebHeaderCollection WebHeaderCollection1 = request.Headers;
                WebHeaderCollection1.Add("Accept-Language:" + Languages.Items[i]);
                HttpRequestCachePolicy policy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
                request.CachePolicy = policy;
                request.Timeout = 10000;
                string msg = null;
                string response_url = "";
                string IsFromCache = "";
                try
                {
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    response_url = response.ResponseUri.AbsoluteUri;
                    IsFromCache = " IsFromCache? " + response.IsFromCache.ToString();
                }
                catch (Exception ex)
                {
                    msg = ex.Message;
                }
                double time = (Environment.TickCount - Tickcunt1) / 1000.0;
                Result.Text += response_url + " time: " + time + "  " + msg + "ThreadID: " + Thread.CurrentThread.ManagedThreadId + IsFromCache + "\r\n";
                Thread.Sleep(0);
                request.Abort();
            }
        }
    }
}