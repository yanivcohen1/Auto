﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Cache;
using System.Threading;
using System.Windows.Forms;
using WH_MAIN_Service;

namespace AcceptLanguage
{
    public partial class MAIN_AL : Form
    {
        AutomationEntities BRAND_DB_Ent;
        Common _Common;
        List<HttpWebRequest> RequestList;
        HttpWebResponse[] GlobRespose;
        List<string> URLs;
        List<string> AcceptLanguages;
        bool start;
        string status;
        bool RunAll;
        int error_index = -1;
        Common.Status[] stat;
        bool totalPass = true;

        public MAIN_AL()
        {
            InitializeComponent();
            start = false;
        }

        private void Form_Load(object sender, System.EventArgs e)
        {
            Bstop.Text = "Start";
            checkAll.Checked = false;
            BransList.Enabled = true;
            RunAll = false;
            string error;
            _Common = new Common(out BRAND_DB_Ent, out error);
            toolStripStatusLabel1.Text = error;
            //BRAND_DB_Ent.Connection.State
            BransList.DataSource = BRAND_DB_Ent.BRAND;
            BransList.DisplayMember = "Brand_Name";
            toolStripStatusLabel2.Text = "Idle";
        }

        private void MainRun(BRAND selectedBrand)
        {
            URLs = new List<string>();
            AcceptLanguages = new List<string>();
            decimal selectedBrand_ID = selectedBrand.Brand_ID;
            //Uses Linq-to-Entities
            IQueryable<BRAND_LANGUAGE> BRAND_LANGUAGE_Query = from p in BRAND_DB_Ent.BRAND_LANGUAGE
                                                              where p.Brand_ID == selectedBrand_ID
                                                              select p;
            List<BRAND_LANGUAGE> selectedBRAND_LANGUAGES = BRAND_LANGUAGE_Query.ToList();

            if (selectedBRAND_LANGUAGES != null && selectedBRAND_LANGUAGES.Count > 0 && start)
            {
                RequestList = new List<HttpWebRequest>();
                WebHeaderCollection WebHeaderCollection;
                // Respose = null;
                foreach (var SelectedBRAND_LANGUAGE in selectedBRAND_LANGUAGES)
                {
                    //Add the Accept-Language header in the request.
                    IQueryable<LANGUAGE> LANGUAGE_Query = from p in BRAND_DB_Ent.LANGUAGE
                                                          where p.Language_ID == SelectedBRAND_LANGUAGE.Language_ID
                                                          select p;
                    List<LANGUAGE> selectedLANGUAGEs = LANGUAGE_Query.ToList();
                    foreach (var selectedLANGUAGE in selectedLANGUAGEs)
                    {
                        HttpWebRequest HttpWebRequest = (HttpWebRequest)WebRequest.CreateDefault(new Uri(selectedBrand.Brand_Main_URL));//Create(selectedBrand.Brand_Main_URL);
                        HttpWebRequest.UserAgent = "Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)";
                        WebHeaderCollection = HttpWebRequest.Headers;
                        WebHeaderCollection.Add("Accept-Language:" + selectedLANGUAGE.Language_Browser_Accept_Langauge);
                        HttpRequestCachePolicy policy = new HttpRequestCachePolicy(HttpRequestCacheLevel.NoCacheNoStore);
                        HttpWebRequest.DefaultCachePolicy = policy;
                        RequestList.Add(HttpWebRequest);
                        URLs.Add(SelectedBRAND_LANGUAGE.Brand_Language_URL_Template);
                        AcceptLanguages.Add(selectedLANGUAGE.Language_Browser_Accept_Langauge);
                    }
                }
                //toolStripStatusLabel1.Text = "Sending";
                HttpWebResponse[] Respose;
                error_index = _Common.SendURI(RequestList.ToArray(), RunAll, out Respose, out stat);
                GlobRespose = Respose;
                MethodInvoker mi = new MethodInvoker(this.UpdatePanel);
                // Call BeginInvoke on the Form and wait to EndInvoke
                IAsyncResult tag = this.BeginInvoke(mi);
                this.EndInvoke(tag);
                foreach (var item in RequestList)
                {
                    item.Abort();
                }
            }
            else
            {
                toolStripStatusLabel1.Text = "Empty Language";
                //UpdatePanel();
            }
        }

        private void UpdatePanel()
        {
            if (GlobRespose != null)
            {
                string ResponseUri = "";
                bool Pass = true;
                string msg = null;
                string ConcatMsg = null;
                for (int i = 0; i < stat.Length; i++)
                {
                    string result = "Fail";
                    try
                    {
                        ResponseUri = GlobRespose[i].ResponseUri.AbsoluteUri;
                        if (ResponseUri.ToLower() == URLs[i].ToString().ToLower())
                            result = "Pass";
                        else
                        {
                            Pass = false;
                        }
                    }
                    catch (Exception ex)
                    {
                        Pass = false;
                        ResponseUri = "";
                    }
                    if (RunAll & (stat[i] == Common.Status.Fail | stat[i] == Common.Status.Pass))
                        msg = "send Accept-Language:" + AcceptLanguages[i] + "\r\nGet ResponseUri:" + ResponseUri + "\r\nAspected URL:" + URLs[i] + "\r\nResult:" + result + "\r\n";
                    else if (!RunAll)
                        msg = "send Accept-Language:" + AcceptLanguages[i] + "\r\nGet ResponseUri:" + ResponseUri + "\r\nAspected URL:" + URLs[i] + "\r\nResult:" + result + "\r\n";
                    ConcatMsg += msg;
                }
                ConcatMsg += "\r\nTotal Brand Result: " + (Pass ? "Pass" : "Fail");
                totalPass &= Pass;
                TextResult.Text = ConcatMsg + "\r\n------------------------------------------------\r\n" + TextResult.Text;
            }
            else
            {
                // TextResult.Text = "Fail";
            }
        }

        private void checkAll_CheckedChanged(object sender, System.EventArgs e)
        {
            BransList.Enabled = !checkAll.Checked;
            RunAll = checkAll.Checked;
        }

        private void Bstop_Click(object sender, EventArgs e)
        {
            if (start)
            {
                Bstop.Text = "Start";
                start = false;
            }
            else
            {
                Bstop.Text = "Stop";
                start = true;
                TextResult.Text = null;
                List<BRAND> SelectedBrands = new List<BRAND>();
                if (!checkAll.Checked)
                    SelectedBrands.Add((BRAND)BransList.SelectedItem);
                else
                {
                    foreach (var brand in BransList.Items)
                    {
                        SelectedBrands.Add((BRAND)brand);
                    }
                }
                Thread NewThread = new Thread(SendURIsTrade);
                NewThread.Start(SelectedBrands.ToArray());
            }
        }

        private void SendURIsTrade(object Brands)
        {
            totalPass = true;
            MethodInvoker mi = new MethodInvoker(this.StatusUpdat);
            foreach (var Brand in (BRAND[])Brands)
            {
                if (start)
                {
                    status = "Running Brand " + Brand.Brand_Name;
                    this.BeginInvoke(mi);
                    MainRun(Brand);
                }
            }
            status = "Finish All- Total Brand's Result: " + (totalPass ? "Pass" : "Fail");
            this.BeginInvoke(mi);
            MethodInvoker mi1 = new MethodInvoker(this.ButtonUpdat);
            start = false;
            this.BeginInvoke(mi1);
        }

        private void StatusUpdat()
        {
            toolStripStatusLabel2.Text = status;
        }

        private void ButtonUpdat()
        {
            Bstop.Text = start ? "Stop" : "Start";
        }
    }
}