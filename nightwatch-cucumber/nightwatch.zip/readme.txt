run
node_modules\.bin\nightwatch --tag google

report
node report.js